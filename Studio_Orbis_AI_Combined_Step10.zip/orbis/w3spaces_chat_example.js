const ORBIS_SERVER = "https://YOUR-SERVICE.onrender.com";

async function askStudioOrbis(message) {
  const response = await fetch(`${ORBIS_SERVER}/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, max_new_tokens: 48, temperature: 0.8, top_k: 30 })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.detail || `Orbis server error: ${response.status}`);
  return data.response;
}
