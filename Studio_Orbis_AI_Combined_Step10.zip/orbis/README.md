# Studio Orbis AI — Step 7 (Render, no Docker)

This package deploys the user's Step 6 homemade model as a small FastAPI service on Render's free Python Web Service. It contains no Dockerfile, no API keys, no external AI API, and no pretrained weights.

## Important limitations

- Render's free instance has limited CPU and RAM and sleeps after inactivity.
- This package uses NumPy for inference instead of loading PyTorch at runtime to reduce memory use. The PyTorch checkpoint was converted locally to NumPy arrays; the learned weights are unchanged.
- The Step 6 model has 386,688 parameters and was trained on a small corpus. It is an experiment, not ChatGPT-level intelligence; responses may be incoherent.
- The free service may still exceed memory or CPU limits. If it does, we will need a lighter runtime or different free compute.

## Deploy using GitHub + Render

1. Download and extract `studio_orbis_ai_step7_render.zip`.
2. Create a new, separate GitHub repository named `studio-orbis-ai-render`. Do not use the WebOS or existing Orbis repositories.
3. Upload the contents of the extracted folder to the repository root. Make sure `app.py`, `requirements.txt`, `render.yaml`, and the `model/` folder are at the root.
4. In Render, choose **New → Blueprint** and connect this repository. Render reads `render.yaml`. Alternatively choose **New → Web Service**, select the repository, choose **Python 3**, Free, build command `pip install --no-cache-dir -r requirements.txt`, start command `uvicorn app:app --host 0.0.0.0 --port $PORT`.
5. Wait for deployment. Test `https://YOUR-SERVICE.onrender.com/health`, then `/`, `/demo`, and `/docs`.
6. The chat endpoint is `POST https://YOUR-SERVICE.onrender.com/chat` with JSON `{"message":"Hello"}`.

## W3Spaces JavaScript example

```js
const ORBIS_SERVER = "https://YOUR-SERVICE.onrender.com";

async function askStudioOrbis(message) {
  const response = await fetch(`${ORBIS_SERVER}/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, max_new_tokens: 48, temperature: 0.8, top_k: 30 })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.detail || `Orbis server error: ${response.status}`);
  return data.response;
}
```

For production, set `ORBIS_ALLOWED_ORIGINS` to your exact W3Spaces website origin (comma-separated if needed). During initial testing it defaults to `*`. Do not put secrets in frontend JavaScript.

## Step 8 — Use an open-source model (gpt-oss) as the engine

`app.py` now forwards `/chat` to any OpenAI-compatible server when `ORBIS_BACKEND_URL` is set.
If it is not set, the tiny Step 6 model is used as before (fallback).

Environment variables (set them in Render -> Environment):

| Variable | Example | Purpose |
|---|---|---|
| `ORBIS_BACKEND_URL` | `http://localhost:11434/v1` | OpenAI-compatible base URL |
| `ORBIS_BACKEND_MODEL` | `gpt-oss:20b` | Model name on that server |
| `ORBIS_BACKEND_API_KEY` | `sk-...` | Only if the server needs a key (keep it server-side) |
| `ORBIS_REASONING_EFFORT` | `low` / `medium` / `high` | Optional |
| `ORBIS_SYSTEM_PROMPT` | `You are Studio Orbis AI...` | Your assistant's personality |

Run gpt-oss locally with Ollama (needs ~16 GB RAM/VRAM for 20b):

    ollama pull gpt-oss:20b
    ollama serve

Render's free tier cannot host gpt-oss itself; point `ORBIS_BACKEND_URL` at a machine or hosted endpoint that can.
The W3Spaces JavaScript example does not need to change.

## Smart routing (hard vs easy questions)

When `ORBIS_BACKEND_URL` is set, every `/chat` request is classified first:

- **Hard** (reasoning, math, code, comparisons, long or multi-part questions) -> sent straight to gpt-oss.
- **Easy** (greetings, short simple questions) -> the Orbis model writes a rough draft, then gpt-oss rewrites it into a clean, correct answer.
- If the backend is down, easy questions fall back to the raw Orbis draft; hard questions return a 502.

Extra environment variables:

| Variable | Default | Purpose |
|---|---|---|
| `ORBIS_ROUTER` | `heuristic` | `heuristic` (free, instant), `llm` (gpt-oss labels each question, more accurate but one extra call), `always_hard`, `always_easy` |
| `ORBIS_HARD_REASONING` | `medium` | gpt-oss reasoning effort for hard questions |
| `ORBIS_EASY_REASONING` | `low` | reasoning effort for easy rewrites |
| `ORBIS_REFINE_PROMPT` | built-in | instructions for the "rewrite the draft" step |

Add `"debug": true` to a `/chat` request to see the route taken, the router's reason and the raw Orbis draft:

    curl -X POST $SERVER/chat -H "Content-Type: application/json" \
      -d '{"message":"Hello","debug":true}'

The response always includes a `route` field (`hard`, `easy`, `easy-fallback` or `local`).

Note: `max_new_tokens` from the client only limits the small Orbis model. gpt-oss answers use the server-side caps
`ORBIS_HARD_MAX_TOKENS` (default 1500) and `ORBIS_EASY_MAX_TOKENS` (default 600), because reasoning models spend
tokens on thinking and a 48-token limit would leave the answer empty.

## Using the Gemini API as the backend

Google's Gemini API has an OpenAI-compatible endpoint, so no code change is needed:

| Variable | Value |
|---|---|
| `ORBIS_BACKEND_URL` | `https://generativelanguage.googleapis.com/v1beta/openai` |
| `ORBIS_BACKEND_MODEL` | a current model ID copied from Google AI Studio |
| `ORBIS_BACKEND_API_KEY` | your Gemini API key (Render Environment tab only) |
| `ORBIS_ROUTER` | `always_hard` |

If the provider rejects the reasoning setting, set `ORBIS_HARD_REASONING` and `ORBIS_EASY_REASONING` to `off`.

## Step 9 — your own trained model (Orbis v2)

If a `model2/` folder (from the training notebook's step 8) sits next to `app.py`, the server loads it with NumPy and
uses it instead of the old 387K Step 6 model. Keep it in `model2/`, NOT in `model/`: both use a file named
`tokenizer.json` in different formats. `/health` shows which model is loaded (`local_model`).

The `model2/` included in this zip is only a 30-step smoke-test checkpoint (about 1.1M parameters, untrained, so it
outputs nonsense). It exists to prove the deployment works. Replace it with the folder from a `small` or `full` run.
`convert_ckpt.py` (numpy only) also converts a `ckpt.pt` on your own computer:
`python convert_ckpt.py --ckpt ckpt.pt --tokenizer tokenizer.json --out model2`

`requirements.txt` now includes `tokenizers`. If Render's build fails on it (Render defaults to Python 3.14), add the
environment variable `PYTHON_VERSION` = `3.12.8` and redeploy.
